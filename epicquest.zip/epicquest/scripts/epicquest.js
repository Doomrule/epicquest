﻿Hooks.once("init", () => {
    console.log("EpicQuest | Initialisation du module...");
});

Hooks.on("renderActorSheet", (app, html, data) => {
    const actor = app.actor;

    // 🔹 Section ajoutée à la fiche
    const customSection = `
  <div class="form-group">
    <label>Rôle :</label>
    <select name="system.role">
      <option value="tank" ${actor.system.role === "tank" ? "selected" : ""}>Tank</option>
      <option value="intermediaire" ${actor.system.role === "intermediaire" ? "selected" : ""}>Intermédiaire</option>
      <option value="leger" ${actor.system.role === "leger" ? "selected" : ""}>Léger</option>
    </select>
  </div>

  <div class="form-group">
    <label>Armure :</label>
    <input type="number" name="system.armure.value" value="${actor.system.armure?.value ?? 0}" /> /
    <input type="number" name="system.armure.max" value="${actor.system.armure?.max ?? 0}" />
  </div>

  <div class="form-group">
    <label>Bonus manuel d’esquive :</label>
    <input type="number" name="system.bonusEsquive" value="${actor.system.bonusEsquive ?? 0}" />
  </div>

  <div class="form-group">
    <label>Chance d’esquive totale :</label>
    <span>${calculerEsquive(actor)}</span>
  </div>

  <div class="form-group">
    <label>Points épiques :</label>
    <input type="number" name="system.pointsEpiques" value="${actor.system.pointsEpiques ?? 0}" />
  </div>
  `;

    // Ajout dans la fiche (en haut)
    html.find(".sheet-header").after(<section class="epicquest-section">${customSection}</section>);
});

// 🧮 Calcul automatique de la chance d’esquive
function calculerEsquive(actor) {
    const base = 10;
    const dex = actor.system.abilities?.dex?.mod ?? 0;
    const bonus = actor.system.bonusEsquive ?? 0;
    return base + dex + bonus;
}